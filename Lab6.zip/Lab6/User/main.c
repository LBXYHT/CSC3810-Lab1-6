#include "stm32f10x.h"
#include "EIE3810_Clock.h"
#include "EIE3810_USART.h"
#include "EIE3810_TFTLCD.h"

void Delay(u32);
void EIE3810_LED_Init(void);
void EIE3810_TIM3_Init(u16 arr, u16 psc);
void EIE3810_TIM4_Init(u16 arr, u16 psc);
void JOYPAD_Init(void);
void JOYPAD_Delay(u16 t);
u8 JOYPAD_Read(void);
void EIE3810_KeyUp_EXTIInit(void);
void EIE3810_TIM3_PWMInit(u16 arr, u16 psc);
void EIE3810_SYSTICK_Init(void);
void TIM3_IRQHandler(void);
void TIM4_IRQHandler(void);
void USART1_IRQHandler(void);
void Game_initialize(void);
void EIE3810_NVIC_SetPriorityGroup(u8 prigroup);
void EXTI2_IRQHandler(void);
void EIE3810_Key_Init(void);
void EXTI0_IRQHandler(void);

#define DS0_OFF GPIOB->BSRR = 1<<5
#define DS0_ON GPIOB->BRR = 1<<5
#define DS1_OFF GPIOE->BSRR = 1<<5
#define DS1_ON GPIOE->BRR = 1<<5

int page = 0, bouncing_amount = 0, time_count = 0, game_status = 1, task2HeartBeat = 0, heartbeat = 0, running_status = 0;
u16 speed = 1, time = 0, total_buzzer = 0, buzzer = 0, x_ball = 240, y_ball=400, x_direct = 1, y_direct = 1, lowboard_left = 180, upboard_left = 180;
//x_direct/y_direct: 1 for initial horizontal/vertical direction, -1 for opposite direction
int direct = 0;
int direction[8][2] = {{-4,1},{-3,2},{-2,3},{-1,4},{1,4},{2,3},{3,2},{4,1}};

void Delay(u32 count) //Delay subroutines generate some time delay by looping
{
	u32 i;
	for (i=0;i<count;i++);
}

void EIE3810_LED_Init(void)
{
	RCC->APB2ENR|=1<<6; //Set RCC->APB2ENR as 1 with offset 6, equaling to set bit IOPEEN as 1
	RCC->APB2ENR|=1<<3; //Set RCC->APB2ENR as 1 with offset 3(or logic), equaling to set bit IOPBEN as 1
	
	//Initialize DS1
	GPIOE->CRL &= 0xFF0FFFFF; //Set CRL to 0x44044444, set all CNFy as 01(general purpose output Open-drain) except CNF5, CNF5 remains push-pull
	GPIOE->CRL |= 0x00300000; //Set CRL to 0x44344444, set MODE as 11(max speed 50MHz)
	
	//Initialize DS0
	GPIOB->CRL &= 0xFF0FFFFF; //Set CRL to 0x44044444, set all CNFy as 01(general purpose output Open-drain) except CNF5, CNF5 remains push-pull
	GPIOB->CRL |= 0x00300000; //Set CRL to 0x44344444, set MODE as 11(max speed 50MHz)
	
}

void EIE3810_TIM3_Init(u16 arr, u16 psc)
{
	//TIM3
	RCC->APB1ENR |=1<<1;//Enable TIM3
	TIM3->ARR = arr;//Set the ARR register
	TIM3->PSC = psc;//Set the psc register
	TIM3->DIER |= 1<<0;//Update interrupt enable
	TIM3->CR1 |= 0x01;//Set up the control register and enable the counter
	NVIC->IP[29] = 0x45;//Set priority level to be 45
	NVIC->ISER[0] |= (1<<29);//Enable interrupt
}


void EIE3810_TIM4_Init(u16 arr, u16 psc)
{
	//TIM4
	RCC->APB1ENR|=1<<2;//TIM4 timer clock enable
	TIM4->ARR=arr;//Set arr value to ARR to set auto-reload register
	TIM4->PSC=psc;//Set psc value to PSC to set prescalar value
	TIM4->DIER|=1<<0;//Set bit0 UIE to 1 to enable update interrupt
	TIM4->CR1|=0x01;//Set bit0 CEN to 1 to enable counter
	NVIC->IP[30]=0x45;//Set 0x45 to priority register of interrupt position #30
	NVIC->ISER[0]=(1<<30);//Enable interrupt position #30
}




void JOYPAD_Init(void)
{
	RCC->APB2ENR|=1<<3; //Enbale GPIOB
	RCC->APB2ENR|=1<<5; //Enable GPIOD
	GPIOB->CRH&=0XFFFF00FF; //Clean the state of port 10, 11 of PB
	GPIOB->CRH|=0X00003800; //Set PB10 as input mode pull-up/pull-down, Set PB11 as output mode push-pull with max 50MHz
	GPIOB->ODR|=3<<10; //Set port output data of PB10 and PB11 as 1
	GPIOD->CRL&=0XFFFF0FFF; //Clean the state of port 3 of PD
	GPIOD->CRL|=0X00003000; //Set PD3 as output mode push-pull with max 50MHz
	GPIOD->ODR|=1<<3; //Set port output data of PD3 as 1
}

void JOYPAD_Delay(u16 t)
{
	while(t--);
}

/*
A:1
B:2
SELECT:4
START:8
UP:16
DOWN:32
LEFT:64
RIGHT:128
*/




u8 JOYPAD_Read(void)
{
	u8 temp=0;
	u8 t;
	GPIOB->BSRR |= 1<<11; //Set PB11, for ODR
	Delay(80); 
	GPIOB->BSRR |= 1<<27; //Reset PB11, for ODR
	for(t=0;t<8;t++)
	{
		temp>>=1; //Shift temp to right for 1 bit
		if ((((GPIOB->IDR)>>10)&0x01)==0) temp|=0x80; //Check if the ith bit of IDR is 1, set bit 8 of temp
		GPIOD->BSRR |= (1<<3); //Set PD3, for ODR
		Delay(80); 
		GPIOD->BSRR |= (1<<19); //Reset PD3, for ODR
		Delay(80); 
	}
	return temp;
}

void EIE3810_KeyUp_EXTIInit(void)
{
	RCC->APB2ENR |= 1<<2; //Enable IOPA for the use of PA0
	GPIOA->CRL &=0xFFFFFFF0; //Clean the state of CNF0 and MODE0 in PA
	GPIOA->CRL |=0x00000008; //Set the state of CNF0 as 10(input with pull-up  / pull-down) amd MODE0 as 00(input mode)
	GPIOA->ODR &= 0; //Set bit0 of ODR as 1 to let PA0 port output data
	RCC->APB2ENR |=0x01; //Enable AFIO
	AFIO->EXTICR[0] &=0xFFFFFFF0; //Clean the state of EXTI0
	AFIO->EXTICR[0] |=0x00000000; //Set the state of EXTI0 as 0000 to select PA0 pin
	EXTI->IMR |= 1; //Set 1 to MR0 of IMR, for interrupt request from line 0 not masked
	EXTI->FTSR |= 1<<0; //Set falling trigger selection register for pin 0
	//EXTI->RTSR |= 1<<0; //Set rising trigger selection register for pin 0
	NVIC->IP[6] = 0X35; //Set the priority register of EXTI0
	NVIC->ISER[0] |= (1<<6); //Enbale interrupt position #6
}

void EIE3810_TIM3_PWMInit(u16 arr, u16 psc)
{
	RCC->APB2ENR |= 1<<3; //Enable GPIOB
	GPIOB->CRL &= 0xFF0FFFFF; //Clean bit23-20 in CRL register
	GPIOB->CRL |= 0x00B00000; //Set value 1010 to bit 23-20 in CRL register, PB5 in output mode Push-pull and max speed 2MHz
	RCC->APB2ENR |= 1<<0; //Enable AFIO
	AFIO->MAPR &= 0xFFFFF3FF; //Clean bit 11-10 in MAPR register for TIM3 remapping
	AFIO->MAPR |= 1<<11; //Set the mode as Partial remap
	RCC->APB1ENR |= 1<<1; //Eanble Timer3 Block
	TIM3->ARR = arr; //Update TIM3 ARR value to be arr
	TIM3->PSC = psc; //Update TIM3 PSC value to be psc
	TIM3->CCMR1 |= 7<<12; //Set output compare 2 mode as 111
	TIM3->CCMR1 |= 1<<11; //Enable output compare 2 preload
	TIM3->CCER |= 1<<4; //Enable compare/capture 2 output
	TIM3->CR1 = 0x0080; //Enable auto-reload preload of TIM3
	TIM3->CR1 |= 1<<0; //Enable the counter
}

void EIE3810_SYSTICK_Init()
{
	SysTick->CTRL = 0; //Clear SysTick->CTRL setting
	SysTick->LOAD = 90000; //90000 in decimal
												//Refer to Cortex-M3 Technical Reference Manual Page8-10.
	SysTick->CTRL = 0x00000003; //FCLK/8
												//Refer to Cortex-M3 Technical Reference Manual Page8-10.
	//CLKSOURCE=0: FCLK/8
	//CLKSOURCE=1: FCLK
	//FCLKSOURCE=0 is sychronized and better than CLKSOURCE=1
	//Refer to clock tree on page 92 of RM0008
}



void TIM3_IRQHandler(void)
{
	if (TIM3->SR & 1<<0)//Check whether the update interrupt flag is 1
	{
		u32 Key = GPIOE->IDR;
		u32 Key_Up = GPIOA->IDR;

		if ((Key_Up & 1<<0) ==1 && page == 0) //Pressing Key_Up, choosing easy level
		{
			char *easy = "Easy";
			char *hard = "Hard";
			int j = 0;
			while(1)
			{
				if (easy[j] == '\0') break;
				
				EIE3810_TFTLCD_ShowChar(50+8*j, 260, easy[j], WHITE, BLUE);
				EIE3810_TFTLCD_ShowChar(50+8*j, 320, hard[j], BLUE, WHITE);
				j++;
			}
			speed = 2;
		}
		
		else if ((Key & 1<<3) == 0 && page == 0) //Pressing Key1, choosing hard level
		{
			char *easy = "Easy";
			char *hard = "Hard";
			int j = 0;
			while(1)
			{
				if (easy[j] == '\0') break;
				
				EIE3810_TFTLCD_ShowChar(50+8*j, 260, easy[j], BLUE, WHITE);
				EIE3810_TFTLCD_ShowChar(50+8*j, 320, hard[j], WHITE, BLUE);
				j++;
			}
			speed = 4;
		}
		
		else if ((Key & 1<<4) == 0 && page == 0)//Pressing Key0, entering the next page
		{
			Random_direction();
			page = 1;
		}
		
		if (page == 2) //Pause/Resume the game
		{
			if (JOYPAD_Read() == 8 || (Key & 1<<3) == 0)
			{
				game_status = ~game_status;
			}
		}

		if (page == 2)
		{
			if (running_status == 0) EIE3810_TFTLCD_FillRectangle(x_ball-30, 60, y_ball-30, 60, WHITE);
			running_status = 1;
		}
		if (page == 2 && game_status == 1 && running_status == 1)
		{
			int x, y;
			x = direction[direct][0];
			y = direction[direct][1];
			//EIE3810_TFTLCD_FillRectangle(x_ball-20, 40, y_ball-20, 40, WHITE);//Clean the original ball
			EIE3810_TFTLCD_DrawCircle(x_ball, y_ball, 16, 1, WHITE);
			if (x_ball>=464 || x_ball<=16) //change horizontal direction
			{
				x_direct = -x_direct;
				buzzer = 1; 
			}
			if (y_ball > 760)
			{
				if (x_ball >= lowboard_left && x_ball <= lowboard_left + 120)//within the lower board, change vertical direction
				{
					y_direct = -y_direct;
					bouncing_amount++;
					speed ++;
					buzzer = 1;
				}
				else 
				{
					page = 3;
				}
			}
			if (y_ball < 40)
			{
				if (x_ball >= upboard_left && y_ball <= upboard_left + 120)//within the upper board, change vertical direction
				{
					y_direct = -y_direct;
					bouncing_amount++;
					speed++;
					buzzer = 1;
				}
				else 
				{
					page = 3;
				}
			}
			
			x_ball = x_ball + speed * x * x_direct;//original x-coordinate + speed*rate*direct
			y_ball = y_ball - speed * y * y_direct;//original y-coordinate + speed*rate*direct
			EIE3810_TFTLCD_DrawCircle(x_ball, y_ball, 16, 1, RED);

			if (buzzer == 1)
			{
				total_buzzer = total_buzzer+1;
				GPIOB->BSRR = 1<<8;
				if (total_buzzer >= 10)
				{
					GPIOB->BRR = 1<<8;
					buzzer = 0;
					total_buzzer = 0;
				}
			}

			//lowerboard movement
			if ((GPIOE->IDR & 1<<2) == 0)//move left
			{
				if (lowboard_left >= 5)
				{
					lowboard_left -= 5;
				}
					EIE3810_TFTLCD_FillRectangle(lowboard_left + 5, 120, 780, 12, WHITE);
					EIE3810_TFTLCD_FillRectangle(lowboard_left, 120, 780, 12, BLACK);				
				
			}
			else if ((GPIOE->IDR & 1<<4) == 0)//move right
			{
				if(lowboard_left <= 355)
				{
					lowboard_left += 5;
				}
					EIE3810_TFTLCD_FillRectangle(lowboard_left-5, 120, 780, 12, WHITE);
					EIE3810_TFTLCD_FillRectangle(lowboard_left, 120, 780, 12, BLACK);
				
			}

			//upperboard movement
			u8 signal;
			signal = JOYPAD_Read();
			u8 bit[8];
			
			bit[0] = (signal&0x01);
			bit[1] = (signal&0x02)>>1;
			bit[2] = (signal&0x04)>>2;
			bit[3] = (signal&0x08)>>3;
			bit[4] = (signal&0x10)>>4;
			bit[5] = (signal&0x20)>>5;
			bit[6] = (signal&0x40)>>6;
			bit[7] = (signal&0x80)>>7;

			if (bit[6] == 0x01)
			{
				if (upboard_left >= 5)
				{
					upboard_left -= 5;
				}
					EIE3810_TFTLCD_FillRectangle(upboard_left+5, 120, 8, 12, WHITE);
					EIE3810_TFTLCD_FillRectangle(upboard_left, 120, 8, 12, BLACK);			
				
			}
			else if(bit[7] == 0x01)
			{
				if(upboard_left <= 355) 
				{
					upboard_left += 5;
				}
					EIE3810_TFTLCD_FillRectangle(upboard_left-5, 120, 8, 12, WHITE);
					EIE3810_TFTLCD_FillRectangle(upboard_left, 120, 8, 12, BLACK);
				
			}
			
			heartbeat++;
			if (heartbeat == 20)
			{
				heartbeat = 0;
				time_count++;
			}
			//Printing the bouncing amounts and game time
			char* bounce = "Bounce: ";
			char* time = "Time: ";
			EIE3810_Print_String(bounce, 5, 400, BLUE, WHITE);
			EIE3810_Print_String(time, 5, 420, BLUE, WHITE);

			int count1 = 0, temp1 = 0;
			int temp_time = time_count;

			int count2 = 0, temp2 = 0;
			int temp_bounce = bouncing_amount;
			if (page == 2)
			{
				while (temp_time != 0)
				{
					count1++;
					temp_time /= 10;
				}

				while (temp_bounce != 0)
				{
					count2++;
					temp_bounce /= 10;
				}

				temp_time = time_count;
				for (int i=count1;i>0;i--)
				{
					temp1 = temp_time % 10;
					print_integer(temp1, 53 + 8*i, 420, BLUE, WHITE);
					temp_time /= 10;
				}

				temp_bounce = bouncing_amount;
				for (int i=count2;i>0;i--)
				{
					temp2 = temp_bounce % 10;
					print_integer(temp2, 69 + 8*i, 400, BLUE, WHITE);
				}

			}
			
			
			
			//Printing game result
			if(page==3)
			{
				game_status = 0;
				char *resultA="Player A is Winner!!!";
				char *resultB="Player B is Winner!!!";
				if(y_ball<50)
				{
					EIE3810_Print_String2412(resultA, 80, 320, WHITE, RED);
				}
				else if (y_ball > 740)
				{
					EIE3810_Print_String2412(resultB, 80, 320, WHITE, RED);
				}
			}
		}
	}
	TIM3->SR &= ~(1<<0);//Clean the bit0 UIF to 0
}



void TIM4_IRQHandler(void)
{
	if ((TIM4->SR & 1<<0))//Check whether the update interrupt flag is 1
	{
		GPIOE->ODR ^=1<<5;//Do the exclusive or operation to change state of PB5(1 to 0, 0 to 1)
	}
	TIM4->SR &= ~(1<<0);//Clean the bit0 UIF to 0
}

void USART1_IRQHandler(void)
{
	u8 buffer;
	if (USART1->SR & (1<<5))
	{
		buffer = USART1->DR;
		direct = buffer;
		page = 2;
		
		char* line = "Random number received is: ";
		//EIE3810_Print_String(line, 100, 200, WHITE, RED);
		int j=0;
		while(1){
			if(line[j]=='\0') break;
				EIE3810_TFTLCD_ShowChar(100+8*j,400,line[j],RED,WHITE);
			  j++;
		}
		print_integer(direct, 324, 400, RED, WHITE);
		
		Delay(20000000);
		
		EIE3810_TFTLCD_Clear(WHITE);
		for (int i=3;i>=0;i--){
			EIE3810_TFTLCD_SevenSegment(202,470,i,BLUE);
			Delay(10000000);
			EIE3810_TFTLCD_Clear(WHITE);
		}
	}
}

void Game_initialize(void)
{
	EIE3810_TFTLCD_DrawCircle(240, 400, 15, 1, RED);//Ball
	EIE3810_TFTLCD_FillRectangle(180, 120, 780, 12, BLACK);//Lowerboard
	EIE3810_TFTLCD_FillRectangle(180, 120, 8, 12, BLACK);//Upperboard
}




void EIE3810_NVIC_SetPriorityGroup(u8 prigroup)
{
	u32 temp1, temp2;
	temp2= prigroup&0x00000007;
	temp2 <<=8; //move temp2 offset left 8 bits, explain why?
	temp1 = SCB->AIRCR; //Read AIRCR in SCB configuration struct for application interrupt / Reset control register
	temp1 &=0x0000F8FF; //Clean bits 8, 9, 11, 16-31 of temp1
	temp1 |=0x05FA0000; //Set bits [27, 16] of temp1 as 010111111010 for orequal calculation with temp2
	temp1 |= temp2;
	SCB->AIRCR = temp1;
}

void EXTI2_IRQHandler(void)
{
	u8 i;
	
	for (i = 0; i < 10; i ++)
	{
		DS0_ON;
		Delay(3000000);
		DS0_OFF;
		Delay(3000000);
	}
	EXTI->PR = 1<<2;
}

void EXTI0_IRQHandler(void)
{
	u8 i;
	
	for (i = 0; i < 10; i ++)
	{
		DS1_ON;
		Delay(3000000);
		DS1_OFF;
		Delay(3000000);
	}
	EXTI->PR = 1<<0;
}

void EIE3810_Key_Init(void)
{
	//PB5
	RCC->APB2ENR|=1<<3;
	GPIOB->CRL&=0xFF0FFFFF;
	GPIOB->CRL|=0x00300000;
	GPIOB->ODR|=1<<5;
	//PE5	
	RCC->APB2ENR|=1<<6;
	GPIOE->CRL&=0xFF0FFFFF;
	GPIOE->CRL|=0x00300000;	
  GPIOE->ODR|=1<<5;
	//PE2
	RCC->APB2ENR|=1<<6;
	GPIOE->CRL&=0xFFFFF0FF;
	GPIOE->CRL|=0x00000800;	
  GPIOE->ODR|=1<<2;
	//PE3
	RCC->APB2ENR|=1<<6;
	GPIOE->CRL&=0xFFFF0FFF;
	GPIOE->CRL|=0x00008000;	
  GPIOE->ODR|=1<<3;	
	//PA0	
	RCC->APB2ENR|=1<<2;
	GPIOA->CRL&=0xFFFFFFF0;
	GPIOA->CRL|=0x00000008;	
  GPIOA->ODR&=0;	
	//PB8	
	GPIOB->CRH&=0xFFFFFFF0;
	GPIOB->CRH|=0x00000003;
	//PE4
	RCC->APB2ENR|=1<<6;
	GPIOE->CRL&=0xFFF0FFFF;
	GPIOE->CRL|=0x00080000;	
  GPIOE->ODR|=1<<4;		
}	


int main(void)
{
	EIE3810_clock_tree_init();//check
	JOYPAD_Init();//check
	EIE3810_NVIC_SetPriorityGroup(5);//check
	EIE3810_TFTLCD_Init();//check
	EIE3810_LED_Init();//check
	EIE3810_TFTLCD_Clear(WHITE);//check
	EIE3810_TIM3_Init(499, 7199);//check
	EIE3810_USART1_init(72, 19313);//check
	EIE3810_USART1_EXTIInit();//check
	EIE3810_Key_Init();
	EIE3810_Show_StartPage();
	while (page == 0){};
		
	while (page == 1){};
		
	Game_initialize();
	
	while(1)
	{
		;
	}
}

