#include "EIE3810_USART.h"

void EIE3810_USART2_init(u32 pclk1, u32 baudrate)
{
	//USART2
	float temp;
	u16 mantissa;
	u16 fraction;
	temp=(float) (pclk1*1000000)/(baudrate*16);
	mantissa=temp;
	fraction=(temp-mantissa)*16;
	mantissa<<=4;
	mantissa+=fraction;
	RCC->APB2ENR |= 1<<2; //Set bit 2 as 1, to enable GPIOA
	GPIOA->CRL &= 0xFFFF00FF; //Set GPIOA bit 15-8 as 0, equaling to CNF3, MODE3, CNF2, MODE2
	GPIOA->CRL |= 0x00008B00; //Set GPIOA CNF3 as 10, CNF2 as 10, MODE2 as 11
	RCC->APB1RSTR |= 1<<17; //Reset USART2
	RCC->APB1RSTR &= ~(1<<17); //Clean the reset state
	USART2->BRR=mantissa;//Set the 16 times temp to reset register, matissa should be 111010100110, saving  [7:0] which should be 10100110
	USART2->CR1=0x2008; //Set bit 3 and bit 13 of CR1 as 1, enable transmitter and USART
}

void EIE3810_USART1_init(u32 pclk2, u32 baudrate)
{
	//USART2
	float temp;
	u16 mantissa;
	u16 fraction;
	//RCC->CFGR |= 1<<13; //Set PCLK2 as system clk
	temp=(float) (pclk2*1000000)/(baudrate*16);
	mantissa=temp;
	fraction=(temp-mantissa)*16;
	mantissa<<=4;
	mantissa+=fraction;
	RCC->APB2ENR |= 1<<2; //Set bit 9 as 1, to enable GPIOA
	GPIOA->CRH &= 0xFFFFF00F; //Set GPIOA bit 15-8 as 0, equaling to CNF10, MODE10, CNF9, MODE9
	GPIOA->CRH |= 0x000008B0; //Set GPIOA CNF10 as 10, CNF9 as 10, MODE9 as 11
	RCC->APB2RSTR |= 1<<14; //Reset USART1
	RCC->APB2RSTR &= ~(1<<14); //Clean the reset state
	USART1->BRR=mantissa;//Set the 16 times temp to reset register, matissa should be 111010100110, saving  [7:0] which should be 10100110
	USART1->CR1=0x202C; //Set bit 3 and bit 13 of CR1 as 1, enable transmitter and USART
}

void USART_print(u8 USARTport, char *st)
{
	u8 i = 0;
	while(st[i] != 0x00)
	{
		if (USARTport == 1) USART1->DR = st[i];
		u8 temp = USART1 ->SR >> 7;
		while (temp == 0) 
		{
			temp = USART1 ->SR >> 7;
		}
		if (USARTport == 2) USART2->DR = st[i];
		u8 temp2 = USART2 ->SR >> 7;
		while (temp2 == 0) 
		{
			temp2 = USART2 ->SR >> 7;
		}
		if (i==255) break;
		i++;
	}
}

void EIE3810_USART1_EXTIInit(void)
{
	NVIC->IP[37]  =0X65;
	NVIC->ISER[1] |=1<<5;
}
