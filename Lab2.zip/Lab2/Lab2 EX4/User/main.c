#include "stm32f10x.h"
#include "EIE3810_Clock.c"
#include "EIE3810_USART.c"



int main(void)
{
	EIE3810_clock_tree_init();
	EIE3810_USART2_init(36, 9600);
	EIE3810_USART1_init(72, 9600);
	while(1)
	{
		USART_print(1,"1234567890"); //This line will be used in Experiment 3
		USART_print(2,"120010058");
	}	
}
