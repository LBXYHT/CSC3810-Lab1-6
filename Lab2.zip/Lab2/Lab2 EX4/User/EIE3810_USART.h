void EIE3810_USART2_init(u32, u32);
void EIE3810_USART1_init(u32, u32);
void USART_print(u8, char*);