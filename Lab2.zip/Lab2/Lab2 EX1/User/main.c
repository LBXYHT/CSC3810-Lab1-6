#include "stm32f10x.h"
void EIE3810_clock_tree_init(void);
void EIE3810_USART2_init(u32, u32);
void Delay(u32);


int main(void)
{
	EIE3810_clock_tree_init();
	EIE3810_USART2_init(36, 9600);
	//USART_print(1,"1234567890"); //This line will be used in Experiment 3
	while(1)
	{
		USART2->DR = 0x41;//Transmit 0x41 to data register of USART2
		Delay(100);		
		USART2->DR = 0x42;//Transmit 0x42 to data register of USART2
		Delay(100);
		Delay(1000000);
	}	
}

void Delay(u32 count) 
{
	u32 i;
	for (i=0;i<count;i++);
}

void EIE3810_clock_tree_init(void)
{
	u8 PLL=7;
	u8 temp=0;
	RCC->CR |= 0x00010000; //Set Clock configuration register CR bit 16 to 1, enable HSE clock
	while(!((RCC->CR>>17)&0x1));//Check whether CR's bit 17 is 0, when it is 0, while(true)
	RCC->CFGR &= 0xFFFDFFFF; //Set Clock configuration register CFGR bit 17 to 0
	RCC->CFGR |= 1<<16; //Set Clock configuration register CFGR bit 16 to 1, select clock from PREDIV1 as PLL input clock
	RCC->CFGR |= PLL<<18; //Set Clock configuration register CFGR bit 18 to PLL, providing external clock
	RCC->CR |=0x01000000;//Set Clock configuration register CR bit 24 to 1, enable PLL-setting PLL on
	while(!(RCC->CR>>25));//Check whether CR bit 25 is 0, equal to 0 means condition true
	RCC->CFGR &=0xFFFFFFFE;//Set Clock configuration register CFGR bit 0 to 0
	RCC->CFGR |=0x00000002;//Set Clock configuration register CFGR bit 1 to 1, select PLL as clock
	while(temp !=0x02) //Check whether temp is not 0x02, when PLL is clock, the condition is true
	{
		temp=RCC->CFGR>>2;
		temp &= 0x03; //set temp to 0 except the bit 0, 1
	}	
	RCC->CFGR &= 0xFFFFFC0F;//Set CFGR bits 4,5,6,7,8,9 to 0
	RCC->CFGR |= 0x00000400;//Set CFGR bit 10 to 1, set HCLK divided by 2
	FLASH->ACR = 0x32;//Set FLASH with 2 wait states	
	RCC->APB1ENR |= 1<<17; //Set APB1 periphral clock enable register to 1
}

void EIE3810_USART2_init(u32 pclk1, u32 baudrate)
{
	//USART2
	float temp;
	u16 mantissa;
	u16 fraction;
	temp=(float) (pclk1*1000000)/(baudrate*16);
	mantissa=temp;
	fraction=(temp-mantissa)*16;
	mantissa<<=4;
	mantissa+=fraction;
	RCC->APB2ENR |= 1<<2; //Set bit 2 as 1, to enable GPIOA
	GPIOA->CRL &= 0xFFFF00FF; //Set GPIOA bit 15-8 as 0, equaling to CNF3, MODE3, CNF2, MODE2
	GPIOA->CRL |= 0x00008B00; //Set GPIOA CNF3 as 10, CNF2 as 10, MODE2 as 11
	RCC->APB1RSTR |= 1<<17; //Reset USART2
	RCC->APB1RSTR &= ~(1<<17); //Clean the reset state
	USART2->BRR=mantissa;//Set the 16 times temp to reset register, matissa should be 111010100110, saving  [7:0] which should be 10100110
	USART2->CR1=0x2008; //Set bit 3 and bit 13 of CR1 as 1, enable transmitter and USART
}
