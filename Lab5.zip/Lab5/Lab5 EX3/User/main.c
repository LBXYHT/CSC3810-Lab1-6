#include "stm32f10x.h"
#include "EIE3810_Clock.h"

u8 task1HeartBeat;
void EIE3810_LED_Init(void);
void EIE3810_NVIC_SetPriorityGroup(u8 prigroup);

#define DS0_OFF GPIOB->BSRR = 1<<5
#define DS0_ON GPIOB->BRR = 1<<5
#define DS1_OFF GPIOE->BSRR = 1<<5
#define DS1_ON GPIOE->BRR = 1<<5

void Delay(u32 count) //Delay subroutines generate some time delay by looping
{
	u32 i;
	for (i=0;i<count;i++);
}

void EIE3810_LED_Init(void)
{
	RCC->APB2ENR|=1<<6; //Set RCC->APB2ENR as 1 with offset 6, equaling to set bit IOPEEN as 1
	RCC->APB2ENR|=1<<3; //Set RCC->APB2ENR as 1 with offset 3(or logic), equaling to set bit IOPBEN as 1
	
	//Initialize DS1
	GPIOE->CRL &= 0xFF0FFFFF; //Set CRL to 0x44044444, set all CNFy as 01(general purpose output Open-drain) except CNF5, CNF5 remains push-pull
	GPIOE->CRL |= 0x00300000; //Set CRL to 0x44344444, set MODE as 11(max speed 50MHz)
	
	//Initialize DS0
	GPIOB->CRL &= 0xFF0FFFFF; //Set CRL to 0x44044444, set all CNFy as 01(general purpose output Open-drain) except CNF5, CNF5 remains push-pull
	GPIOB->CRL |= 0x00300000; //Set CRL to 0x44344444, set MODE as 11(max speed 50MHz)
	
}

void EIE3810_NVIC_SetPriorityGroup(u8 prigroup)
{
	u32 temp1, temp2;
	temp2= prigroup&0x00000007;
	temp2 <<=8; //move temp2 offset left 8 bits, explain why?
	temp1 = SCB->AIRCR; //Read AIRCR in SCB configuration struct for application interrupt / Reset control register
	temp1 &=0x0000F8FF; //Clean bits 8, 9, 11, 16-31 of temp1
	temp1 |=0x05FA0000; //Set bits [27, 16] of temp1 as 010111111010 for orequal calculation with temp2
	temp1 |= temp2;
	SCB->AIRCR = temp1;
}


void EIE3810_SYSTICK_Init()
{
	SysTick->CTRL = 0; //Clear SysTick->CTRL setting
	SysTick->LOAD = 0x00015F8F; //89999 in decimal
												//Refer to Cortex-M3 Technical Reference Manual Page8-10.
	SysTick->CTRL = 0x00000003; //FCLK/8
												//Refer to Cortex-M3 Technical Reference Manual Page8-10.
	//CLKSOURCE=0: FCLK/8
	//CLKSOURCE=1: FCLK
	//FCLKSOURCE=0 is sychronized and better than CLKSOURCE=1
	//Refer to clock tree on page 92 of RM0008
}

int main(void)
{
	int T0_after, T1_after, T0_before, T1_before;
	EIE3810_clock_tree_init();
	EIE3810_LED_Init();
	EIE3810_NVIC_SetPriorityGroup(5);//Set PRIGROUP
	EIE3810_SYSTICK_Init();
	//EIE3810_TIM3_Init(4999, 7199);//Set autoreload value as 4999, and prescalar value as 7199
	//EIE3810_TIM4_Init(4999, 7199);//Set autoreload value as 4999, and prescalar value as 7199
	while(1)
	{
		T0_before = task1HeartBeat / 25;
		T1_before = task1HeartBeat / 10;
		if (T0_before != T0_after)
		{
			GPIOE->ODR ^= 1<<5;
		}
		if (T1_before != T1_after)
		{
			GPIOB->ODR ^= 1<<5;
		}
		if (task1HeartBeat>=99)
		{
			task1HeartBeat=0;
			//Write task1 here.
		}
		T0_after = T0_before;
		T1_after = T1_before;
	}
}
