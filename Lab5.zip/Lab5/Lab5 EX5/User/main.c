#include "stm32f10x.h"
#include "EIE3810_Clock.h"
#include "EIE3810_USART.h"
#include "EIE3810_TFTLCD.h"
#include "Font.H"

void EIE3810_LED_Init(void);
void EIE3810_NVIC_SetPriorityGroup(u8 prigroup);
void EIE3810_TFTLCD_ShowChar(u16 x, u16 y, u8 ASCII, u16 color, u16 bgcolor);


void Delay(u32 count) //Delay subroutines generate some time delay by looping
{
	u32 i;
	for (i=0;i<count;i++);
}

void EIE3810_LED_Init(void)
{
	RCC->APB2ENR|=1<<6; //Set RCC->APB2ENR as 1 with offset 6, equaling to set bit IOPEEN as 1
	RCC->APB2ENR|=1<<3; //Set RCC->APB2ENR as 1 with offset 3(or logic), equaling to set bit IOPBEN as 1
	
	//Initialize DS1
	GPIOE->CRL &= 0xFF0FFFFF; //Set CRL to 0x44044444, set all CNFy as 01(general purpose output Open-drain) except CNF5, CNF5 remains push-pull
	GPIOE->CRL |= 0x00300000; //Set CRL to 0x44344444, set MODE as 11(max speed 50MHz)
	
	//Initialize DS0
	GPIOB->CRL &= 0xFF0FFFFF; //Set CRL to 0x44044444, set all CNFy as 01(general purpose output Open-drain) except CNF5, CNF5 remains push-pull
	GPIOB->CRL |= 0x00300000; //Set CRL to 0x44344444, set MODE as 11(max speed 50MHz)
	
}

void EIE3810_TIM3_Init(u16 arr, u16 psc)
{
	//TIM3
	RCC->APB1ENR |=1<<1;//Enable TIM3
	TIM3->ARR = arr;//Set the ARR register
	TIM3->PSC = psc;//Set the psc register
	TIM3->DIER |= 1<<0;//Update interrupt enable
	TIM3->CR1 |= 0x01;//Set up the control register and enable the counter
	NVIC->IP[29] = 0x45;//Set priority level to be 45
	NVIC->ISER[0] |= (1<<29);//Enable interrupt
}

void JOYPAD_Init(void)
{
	RCC->APB2ENR|=1<<3; //Enbale GPIOB
	RCC->APB2ENR|=1<<5; //Enable GPIOD
	GPIOB->CRH&=0XFFFF00FF; //Clean the state of port 10, 11 of PB
	GPIOB->CRH|=0X00003800; //Set PB10 as input mode pull-up/pull-down, Set PB11 as output mode push-pull with max 50MHz
	GPIOB->ODR|=3<<10; //Set port output data of PB10 and PB11 as 1
	GPIOD->CRL&=0XFFFF0FFF; //Clean the state of port 3 of PD
	GPIOD->CRL|=0X00003000; //Set PD3 as output mode push-pull with max 50MHz
	GPIOD->ODR|=1<<3; //Set port output data of PD3 as 1
}

void JOYPAD_Delay(u16 t)
{
	while(t--);
}

u8 JOYPAD_Read(void)
{
	u8 temp=0;
	u8 t;
	GPIOB->BSRR |= 1<<11; //Set PB11, for ODR
	Delay(80); 
	GPIOB->BSRR |= 1<<27; //Reset PB11, for ODR
	for(t=0;t<8;t++)
	{
		temp>>=1; //Shift temp to right for 1 bit
		if ((((GPIOB->IDR)>>10)&0x01)==0) temp|=0x80; //Check if the ith bit of IDR is 1, set bit 8 of temp
		GPIOD->BSRR |= (1<<3); //Set PD3, for ODR
		Delay(80); 
		GPIOD->BSRR |= (1<<19); //Reset PD3, for ODR
		Delay(80); 
	}
	return temp;
}


void TIM3_IRQHandler(void)
{
	u8 signal;
	JOYPAD_Delay(7500);
	signal = JOYPAD_Read();
	u8 bit[8];
	
	bit[0] = (signal&0x01);
	bit[1] = (signal&0x02)>>1;
	bit[2] = (signal&0x04)>>2;
	bit[3] = (signal&0x08)>>3;
	bit[4] = (signal&0x10)>>4;
	bit[5] = (signal&0x20)>>5;
	bit[6] = (signal&0x40)>>6;
	bit[7] = (signal&0x80)>>7;
	
	//Show char A
	if(bit[0] == 0x01)
	{
		EIE3810_TFTLCD_Clear(WHITE);
		EIE3810_TFTLCD_ShowChar(0,0,65,BLACK,WHITE);
	}
	//Show char B
	else if(bit[1] == 0x01)
	{
		EIE3810_TFTLCD_Clear(WHITE);
		EIE3810_TFTLCD_ShowChar(0,0,66,BLACK,WHITE);
	}
	//Show char Select
	else if(bit[2] == 0x01)
	{
		EIE3810_TFTLCD_Clear(WHITE);
		EIE3810_TFTLCD_ShowChar(0,0,83,BLACK,WHITE);
		EIE3810_TFTLCD_ShowChar(8,0,69,BLACK,WHITE);
		EIE3810_TFTLCD_ShowChar(16,0,76,BLACK,WHITE);
		EIE3810_TFTLCD_ShowChar(24,0,69,BLACK,WHITE);
		EIE3810_TFTLCD_ShowChar(32,0,67,BLACK,WHITE);
		EIE3810_TFTLCD_ShowChar(40,0,84,BLACK,WHITE);
	}
	//Show char Start
	else if(bit[3] == 0x01)
	{
		EIE3810_TFTLCD_Clear(WHITE);
		EIE3810_TFTLCD_ShowChar(0,0,83,BLACK,WHITE);
		EIE3810_TFTLCD_ShowChar(8,0,84,BLACK,WHITE);
		EIE3810_TFTLCD_ShowChar(16,0,65,BLACK,WHITE);
		EIE3810_TFTLCD_ShowChar(24,0,82,BLACK,WHITE);
		EIE3810_TFTLCD_ShowChar(32,0,84,BLACK,WHITE);
	}
	//Show char Up
	else if(bit[4] == 0x01)
	{
		EIE3810_TFTLCD_Clear(WHITE);
		EIE3810_TFTLCD_ShowChar(0,0,85,BLACK,WHITE);
		EIE3810_TFTLCD_ShowChar(8,0,80,BLACK,WHITE);
	}
	//Show char Down
	else if(bit[5] == 0x01)
	{
		EIE3810_TFTLCD_Clear(WHITE);
		EIE3810_TFTLCD_ShowChar(0,0,68,BLACK,WHITE);
		EIE3810_TFTLCD_ShowChar(8,0,79,BLACK,WHITE);
		EIE3810_TFTLCD_ShowChar(16,0,87,BLACK,WHITE);
		EIE3810_TFTLCD_ShowChar(24,0,78,BLACK,WHITE);
	}
	//Show char Left
	else if(bit[6] == 0x01)
	{
		EIE3810_TFTLCD_Clear(WHITE);
		EIE3810_TFTLCD_ShowChar(0,0,76,BLACK,WHITE);
		EIE3810_TFTLCD_ShowChar(8,0,69,BLACK,WHITE);
		EIE3810_TFTLCD_ShowChar(16,0,70,BLACK,WHITE);
		EIE3810_TFTLCD_ShowChar(24,0,84,BLACK,WHITE);
	}
	//Show char Left
	else if(bit[7] == 0x01)
	{
		EIE3810_TFTLCD_Clear(WHITE);
		EIE3810_TFTLCD_ShowChar(0,0,82,BLACK,WHITE);
		EIE3810_TFTLCD_ShowChar(8,0,73,BLACK,WHITE);
		EIE3810_TFTLCD_ShowChar(16,0,71,BLACK,WHITE);
		EIE3810_TFTLCD_ShowChar(24,0,72,BLACK,WHITE);
		EIE3810_TFTLCD_ShowChar(32,0,84,BLACK,WHITE);
	}
}

void EIE3810_TFTLCD_ShowChar(u16 x, u16 y, u8 ASCII, u16 color, u16 bgcolor)
{
	//limit to the writing range
	if (ASCII >= 32 && ASCII <= 126)
	{
		//Fill background
		EIE3810_TFTLCD_FillRectangle(x, 8, y, 16, bgcolor);
		for (int i=0;i<=15;i+=2)
		{
			for (int j=0;j<=15;j++)
			{
				//Show the upper part of a char
				if (j<8) 
				{
					int upper_bit = asc2_1608[ASCII-32][i] & 1<<j;
					if (upper_bit != 0)
					{
						EIE3810_TFTLCD_DrawDot(x + i/2, y - j+8, color);
					}
				}
				//Show the lower part of a char
				else 
				{
					int lower_bit = asc2_1608[ASCII-32][i+1] & 1<<(j-8);
					if (lower_bit != 0)
					{
						EIE3810_TFTLCD_DrawDot(x + i/2, y - j+23, color);
					}
				}
			}
		}
	}
}

void EIE3810_NVIC_SetPriorityGroup(u8 prigroup)
{
	u32 temp1, temp2;
	temp2= prigroup&0x00000007;
	temp2 <<=8; //move temp2 offset left 8 bits, explain why?
	temp1 = SCB->AIRCR; //Read AIRCR in SCB configuration struct for application interrupt / Reset control register
	temp1 &=0x0000F8FF; //Clean bits 8, 9, 11, 16-31 of temp1
	temp1 |=0x05FA0000; //Set bits [27, 16] of temp1 as 010111111010 for orequal calculation with temp2
	temp1 |= temp2;
	SCB->AIRCR = temp1;
}


int main(void)
{
	EIE3810_clock_tree_init();
	JOYPAD_Init();
	EIE3810_NVIC_SetPriorityGroup(5);
	EIE3810_TFTLCD_Init();
	Delay(500000);
	EIE3810_TFTLCD_Clear(WHITE);
	EIE3810_TIM3_Init(4999, 7199);
	
	while(1);
}

