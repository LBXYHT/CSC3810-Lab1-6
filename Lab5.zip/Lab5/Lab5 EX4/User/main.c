#include "stm32f10x.h"
#include "EIE3810_Clock.h"


void EIE3810_LED_Init(void);

#define LED0_PWM_VAL TIM3->CCR2

void Delay(u32 count) //Delay subroutines generate some time delay by looping
{
	u32 i;
	for (i=0;i<count;i++);
}

void EIE3810_LED_Init(void)
{
	RCC->APB2ENR|=1<<6; //Set RCC->APB2ENR as 1 with offset 6, equaling to set bit IOPEEN as 1
	RCC->APB2ENR|=1<<3; //Set RCC->APB2ENR as 1 with offset 3(or logic), equaling to set bit IOPBEN as 1
	
	//Initialize DS1
	GPIOE->CRL &= 0xFF0FFFFF; //Set CRL to 0x44044444, set all CNFy as 01(general purpose output Open-drain) except CNF5, CNF5 remains push-pull
	GPIOE->CRL |= 0x00300000; //Set CRL to 0x44344444, set MODE as 11(max speed 50MHz)
	
	//Initialize DS0
	GPIOB->CRL &= 0xFF0FFFFF; //Set CRL to 0x44044444, set all CNFy as 01(general purpose output Open-drain) except CNF5, CNF5 remains push-pull
	GPIOB->CRL |= 0x00300000; //Set CRL to 0x44344444, set MODE as 11(max speed 50MHz)
	
}

void EIE3810_TIM3_PWMInit(u16 arr, u16 psc)
{
	RCC->APB2ENR |= 1<<3; //Enable GPIOB
	GPIOB->CRL &= 0xFF0FFFFF; //Clean bit23-20 in CRL register
	GPIOB->CRL |= 0x00B00000; //Set value 1010 to bit 23-20 in CRL register, PB5 in output mode Push-pull and max speed 2MHz
	RCC->APB2ENR |= 1<<0; //Enable AFIO
	AFIO->MAPR &= 0xFFFFF3FF; //Clean bit 11-10 in MAPR register for TIM3 remapping
	AFIO->MAPR |= 1<<11; //Set the mode as Partial remap
	RCC->APB1ENR |= 1<<1; //Eanble Timer3 Block
	TIM3->ARR = arr; //Update TIM3 ARR value to be arr
	TIM3->PSC = psc; //Update TIM3 PSC value to be psc
	TIM3->CCMR1 |= 7<<12; //Set output compare 2 mode as 111
	TIM3->CCMR1 |= 1<<11; //Enable output compare 2 preload
	TIM3->CCER |= 1<<4; //Enable compare/capture 2 output
	TIM3->CR1 = 0x0080; //Enable auto-reload preload of TIM3
	TIM3->CR1 |= 1<<0; //Enable the counter
}


int main(void)
{
	u16 LED0PWMVal=0;
	u8 dir=1;
	EIE3810_clock_tree_init();
	EIE3810_LED_Init();
	EIE3810_TIM3_PWMInit(9999, 71); //Set TIMER3 with arr = 9999, psc = 71, 50Hz
	while(1)
	{
		Delay(1500);
		if (dir) LED0PWMVal++; //When dir==1, upcounting mode, the value increase 1 once
		else LED0PWMVal--; //When dir==0, downcounting mode, the value decrease 1 once
		if (LED0PWMVal >5000) dir=0; //For a maximum value, the direction is set to be downcounting
		if (LED0PWMVal ==0) dir=1; //When the value is 0, the direction is set to be upcounting
		LED0_PWM_VAL = LED0PWMVal; //Update TIM3->CCR2 for new capture/compare 2 value, receiving changing frequency
	}
}
