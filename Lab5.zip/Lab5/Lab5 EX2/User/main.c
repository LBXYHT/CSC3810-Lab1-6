#include "stm32f10x.h"
#include "EIE3810_Clock.h"


void EIE3810_LED_Init(void);
void EIE3810_NVIC_SetPriorityGroup(u8 prigroup);
void EIE3810_TIM3_Init(u16 arr, u16 psc);
void EIE3810_TIM4_Init(u16 arr, u16 psc);

#define DS0_OFF GPIOB->BSRR = 1<<5
#define DS0_ON GPIOB->BRR = 1<<5
#define DS1_OFF GPIOE->BSRR = 1<<5
#define DS1_ON GPIOE->BRR = 1<<5

void Delay(u32 count) //Delay subroutines generate some time delay by looping
{
	u32 i;
	for (i=0;i<count;i++);
}

int main(void)
{
	EIE3810_clock_tree_init();
	EIE3810_LED_Init();
	EIE3810_NVIC_SetPriorityGroup(5);//Set PRIGROUP
	EIE3810_TIM3_Init(4999, 7199);//Set autoreload value as 4999, and prescalar value as 7199
	EIE3810_TIM4_Init(4999, 7199);//Set autoreload value as 5000, and prescalar value as 7200
	while(1)
	{
		
	}
}

void EIE3810_LED_Init(void)
{
	RCC->APB2ENR|=1<<6; //Set RCC->APB2ENR as 1 with offset 6, equaling to set bit IOPEEN as 1
	RCC->APB2ENR|=1<<3; //Set RCC->APB2ENR as 1 with offset 3(or logic), equaling to set bit IOPBEN as 1
	
	//Initialize DS1
	GPIOE->CRL &= 0xFF0FFFFF; //Set CRL to 0x44044444, set all CNFy as 01(general purpose output Open-drain) except CNF5, CNF5 remains push-pull
	GPIOE->CRL |= 0x00300000; //Set CRL to 0x44344444, set MODE as 11(max speed 50MHz)
	
	//Initialize DS0
	GPIOB->CRL &= 0xFF0FFFFF; //Set CRL to 0x44044444, set all CNFy as 01(general purpose output Open-drain) except CNF5, CNF5 remains push-pull
	GPIOB->CRL |= 0x00300000; //Set CRL to 0x44344444, set MODE as 11(max speed 50MHz)
	
	DS0_OFF;//Set led0 off at the beginning but led1 remains on
	
}

void EIE3810_NVIC_SetPriorityGroup(u8 prigroup)
{
	u32 temp1, temp2;
	temp2= prigroup&0x00000007;
	temp2 <<=8; //move temp2 offset left 8 bits, explain why?
	temp1 = SCB->AIRCR; //Read AIRCR in SCB configuration struct for application interrupt / Reset control register
	temp1 &=0x0000F8FF; //Clean bits 8, 9, 11, 16-31 of temp1
	temp1 |=0x05FA0000; //Set bits [27, 16] of temp1 as 010111111010 for orequal calculation with temp2
	temp1 |= temp2;
	SCB->AIRCR = temp1;
}

void EIE3810_TIM3_Init(u16 arr, u16 psc)
{
	//TIM3
	RCC->APB1ENR|=1<<1;//TIM3 timer clock enable
	TIM3->ARR=arr;//Set arr value to ARR to set auto-reload register
	TIM3->PSC=psc;//Set psc value to PSC to set prescalar value
	TIM3->DIER|=1<<0;//Set bit0 UIE to 1 to enable update interrupt
	TIM3->CR1|=0x01;//Set bit0 CEN to 1 to enable counter
	NVIC->IP[29]=0x45;//Set 0x45 to priority register of interrupt position #29
	NVIC->ISER[0]=(1<<29);//Enable interrupt position #29
}

void TIM3_IRQHandler(void)
{
	if (TIM3->SR & 1<<0)//Check whether the update interrupt flag is 1
	{
		GPIOB->ODR ^=1<<5;//Do the exclusive or operation to change state of bit5(1 to 0, 0 to 1)
	}
	TIM3->SR &= ~(1<<0);//Clean the bit0 UIF to 0
}

void EIE3810_TIM4_Init(u16 arr, u16 psc)
{
	//TIM4
	RCC->APB1ENR|=1<<2;//TIM4 timer clock enable
	TIM4->ARR=arr;//Set arr value to ARR to set auto-reload register
	TIM4->PSC=psc;//Set psc value to PSC to set prescalar value
	TIM4->DIER|=1<<0;//Set bit0 UIE to 1 to enable update interrupt
	TIM4->CR1|=0x01;//Set bit0 CEN to 1 to enable counter
	NVIC->IP[30]=0x45;//Set 0x45 to priority register of interrupt position #30
	NVIC->ISER[0]=(1<<30);//Enable interrupt position #30
}

void TIM4_IRQHandler(void)
{
	if ((TIM4->SR & 1<<0))//Check whether the update interrupt flag is 1
	{
		GPIOE->ODR ^=1<<5;//Do the exclusive or operation to change state of PB5(1 to 0, 0 to 1)
	}
	TIM4->SR &= ~(1<<0);//Clean the bit0 UIF to 0
}
