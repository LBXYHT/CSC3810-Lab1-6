#include "stm32f10x.h"
#include "EIE3810_LED.h"

// put your code here
void EIE3810_LED_Init() {
	//Set GPIOE
	RCC->APB2ENR|=1<<6; //Set RCC->APB2ENR as 1 with offset 6, equaling to set bit IOPEEN as 1
	//Set GPIOB
	RCC->APB2ENR|=1<<3; //Set RCC->APB2ENR as 1 with offset 3(or logic), equaling to set bit IOPBEN as 1
	
	//Set PE5 to implement LED1
	GPIOE->CRL &= 0xFF0FFFFF; //Set CRL to 0x44044444, set all CNFy as 01(general purpose output Open-drain) except CNF5, CNF5 remains push-pull
	GPIOE->CRL |= 0x00300000; //Set CRL to 0x44344444, set MODE as 11(max speed 50MHz)
	
	//Set PB5 to implement LED0
	GPIOB->CRL &= 0xFF0FFFFF; //Set CRL to 0x44044444, set all CNFy as 01(general purpose output Open-drain) except CNF5, CNF5 remains push-pull
	GPIOB->CRL |= 0x00300000; //Set CRL to 0x44344444, set MODE as 11(max speed 50MHz)
	
	
	while(1) {
		u32 state_key1 = (GPIOE->IDR & 0x00000008) >> 3; //Use a state variable to eliminate the bouncing problem
		
		//Check whether Key2 is pressed(IDR at bit2 is 1), if yes, reset PB5 to turn off the lit, if no, set PB5 to turn on the lit
		if ((GPIOE->IDR & (1<<2)) != 0x00000004) { 
			GPIOB->BRR = 1<<5; //Set BR5 as 1, reset the corresponding ODR5 bit
		} else {
			GPIOB->BSRR = 1<<5; //Set BS5 as 1, set the corrsponding ODR5 bit
		}
		
		//Check whether the state of key1 for stablizing, if yes, check whether key1 is pressed, yes then reset led1, no then set led1; 
		if (state_key1 == 0) { //check the initial state of key1
			if ((GPIOE->ODR & 0x00000020) >> 5 != 0) { //check the set or reset state
				GPIOE->BRR = 1<<5; // reset led1, turn off it
			} else {
				GPIOE->BSRR = 1<<5; //set led1, turn on it
			}
			Delay(100000);
			//Check when bit3 of IDR is 0, state is 0, set the state to 1 so that in next while loop, the if content will not matter, remaining the led's state
			while (state_key1 == 0) {
				state_key1 = (GPIOE->IDR & 0X00000008) >> 3; //prevent led1 from change after release key1
				Delay(100000);
			}
		}
	}
}