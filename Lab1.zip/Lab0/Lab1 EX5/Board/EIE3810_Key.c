#include "stm32f10x.h"
#include "EIE3810_KEY.h"

// put your procedure and code here

void EIE3810_Key_Init() {
	//Set GPIOE
	RCC->APB2ENR|=1<<6; //Set RCC->APB2ENR as 1 with offset 6, equaling to set bit IOPEEN as 1
	//Set GPIOA
	RCC->APB2ENR|=1<<2; //Set RCC->APB2ENR as 1 with offset 2(or logic), equaling to set bit IOPAEN as 1
	
	//Set PA0 to implement Key_Up
	GPIOA->CRL &= 0xFFFFFFF0; //Set CRL to 0x44444044, set all CNFy as 01(floating input) except CNF0, CNF0 should be 00, set to analog mode, 0
	GPIOA->CRL |= 0x00000008; //Set CRL to 0x44444844, set all CNFy as 01(floating input) except CNF0, CNF0 should be 10, input with pull-up/pull-down
	
	//Set PE2 to implement Key2
	GPIOE->CRL &= 0xFFFFF0FF; //Set CRL to 0x44444044, set all CNFy as 01(floating input) except CNF2, CNF2 should be 00, set to analog mode, 0
	GPIOE->CRL |= 0x00000800; //Set CRL to 0x44444844, set all CNFy as 01(floating input) except CNF2, CNF2 should be 10, input with pull-up/pull-down
	GPIOE->ODR |= 1<<2; //Set pull-up state
	
	//Set PE3 to implement Key1
	GPIOE->CRL &= 0xFFFF0FFF; //Set CRL to 0x44444044, set all CNFy as 01(floating input) except CNF2, CNF2 should be 00, set to analog mode, 0
	GPIOE->CRL |= 0x00008000; //Set CRL to 0x44444844, set all CNFy as 01(floating input) except CNF2, CNF2 should be 10, input with pull-up/pull-down
	GPIOE->ODR |= 1<<3; //Set pull-up state
}