#include "stm32f10x.h"
#include "EIE3810_Buzzer.h"

// put your procedure and code here

void EIE3810_Buzzer_Init() {
	//Set GPIOB
	RCC->APB2ENR|=1<<3; //Set RCC->APB2ENR as 1 with offset 3(or logic), equaling to set bit IOPBEN as 1
	
	//Set PB8 to implement Buzzer
	GPIOB->CRH &= 0xFFFFFFF0; //Set CRL to 0x44444440, set all CNFy as 01(general purpose output Open-drain) except CNF8, CNF8 remains push-pull
	GPIOB->CRH |= 0x00000003; //Set CRL to 0x44444443, set MODE as 11(max speed 50MHz)
	
	while(1) {

		u32 state_buzzer = GPIOA->IDR & 0x00000001; //Use a state variable to eliminate the bouncing problem
		
		//Check the state of keyup for stablizing, if yes, check whether keyup is pressed, yes then reset buzzer, no then set buzzer;
		if (state_buzzer == 1) { //check the initial state of buzzer
			if ((GPIOB->ODR & 0x00000100) >> 8 == 1) { //check the set or reset state
				GPIOB->BRR = 1<<8; // reset buzzer, turn off it
			} else {
				GPIOB->BSRR = 1<<8; //set buzzer, turn on it
			}
			Delay(10000);
			//Check when bit0 of IDR is 1, state is 1, set the state to 0 so that in next while loop, the if content will not matter, remaining the buzzer's state
			while (state_buzzer == 1) {
				state_buzzer = (GPIOA->IDR & 0X00000001); //prevent buzzer from change after release keyup
				Delay(10000);
			}
		}
	}
}