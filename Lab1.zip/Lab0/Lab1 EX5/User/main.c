#include "stm32f10x.h"
#include "EIE3810_LED.h"
#include "EIE3810_KEY.h"
#include "EIE3810_Buzzer.h"

void Delay(u32 count) //Delay subroutines generate some time delay by looping
{
	u32 i;
	for (i=0;i<count;i++);
}

int main(void)
{
	EIE3810_Key_Init(); // Include functions
	EIE3810_LED_Init(); // Include functions
	EIE3810_Buzzer_Init(); // Include functions
}
