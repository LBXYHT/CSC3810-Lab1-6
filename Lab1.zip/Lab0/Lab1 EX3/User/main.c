#include "stm32f10x.h"

void Delay(u32 count) //Delay subroutines generate some time delay by looping
{
	u32 i;
	for (i=0;i<count;i++);
}

int main(void)
{
	RCC->APB2ENR|=1<<3; //Set RCC->APB2ENR as 1 with offset 3, equaling to set bit IOPBEN as 1
	GPIOB->CRL &= 0xFF0FFFFF; //Set CRL to 0x44044444, set all CNFy as 01(general purpose output Open-drain) except CNF5, CNF5 remains push-pull
	GPIOB->CRL |= 0x00300000; //Set CRL to 0x44344444, set MODE as 11(max speed 50MHz)
	
	while(1)
	{
		GPIOB->BRR = 1<<5; //Set BS5 as 1, reset the corresponding ODR5 bit
		Delay(10245901);
		GPIOB->BSRR = 1<<5; //Set BR5 as 1, set the corrsponding ODR5 bit
		Delay(10245901);
	}
}
