#include "stm32f10x.h"

void Delay(u32 count) //Delay subroutines generate some time delay by looping
{
	u32 i;
	for (i=0;i<count;i++);
}

int main(void)
{
	//Set GPIOE
	RCC->APB2ENR|=1<<6; //Set RCC->APB2ENR as 1 with offset 6, equaling to set bit IOPEEN as 1
	//Set GPIOB
	RCC->APB2ENR|=1<<3; //Set RCC->APB2ENR as 1 with offset 3(or logic), equaling to set bit IOPBEN as 1
	//Set GPIOA
	RCC->APB2ENR|=1<<2; //Set RCC->APB2ENR as 1 with offset 2(or logic), equaling to set bit IOPAEN as 1
	
	//Set PA0 to implement Key_Up
	GPIOA->CRL &= 0xFFFFFFF0; //Set CRL to 0x44444044, set all CNFy as 01(floating input) except CNF0, CNF0 should be 00, set to analog mode, 0
	GPIOA->CRL |= 0x00000008; //Set CRL to 0x44444844, set all CNFy as 01(floating input) except CNF0, CNF0 should be 10, input with pull-up/pull-down
	
	//Set PE2 to implement Key2
	GPIOE->CRL &= 0xFFFFF0FF; //Set CRL to 0x44444044, set all CNFy as 01(floating input) except CNF2, CNF2 should be 00, set to analog mode, 0
	GPIOE->CRL |= 0x00000800; //Set CRL to 0x44444844, set all CNFy as 01(floating input) except CNF2, CNF2 should be 10, input with pull-up/pull-down
	GPIOE->ODR |= 1<<2; //Set pull-up state
	
	//Set PE3 to implement Key1
	GPIOE->CRL &= 0xFFFF0FFF; //Set CRL to 0x44444044, set all CNFy as 01(floating input) except CNF2, CNF2 should be 00, set to analog mode, 0
	GPIOE->CRL |= 0x00008000; //Set CRL to 0x44444844, set all CNFy as 01(floating input) except CNF2, CNF2 should be 10, input with pull-up/pull-down
	GPIOE->ODR |= 1<<3; //Set pull-up state
	
	//Set PE5 to implement LED1
	GPIOE->CRL &= 0xFF0FFFFF; //Set CRL to 0x44044444, set all CNFy as 01(general purpose output Open-drain) except CNF5, CNF5 remains push-pull
	GPIOE->CRL |= 0x00300000; //Set CRL to 0x44344444, set MODE as 11(max speed 50MHz)
	
	//Set PB5 to implement LED0
	GPIOB->CRL &= 0xFF0FFFFF; //Set CRL to 0x44044444, set all CNFy as 01(general purpose output Open-drain) except CNF5, CNF5 remains push-pull
	GPIOB->CRL |= 0x00300000; //Set CRL to 0x44344444, set MODE as 11(max speed 50MHz)
	
	//Set PB8 to implement Buzzer
	GPIOB->CRH &= 0xFFFFFFF0; //Set CRL to 0x44444440, set all CNFy as 01(general purpose output Open-drain) except CNF8, CNF8 remains push-pull
	GPIOB->CRH |= 0x00000003; //Set CRL to 0x44444443, set MODE as 11(max speed 50MHz)
	
	while(1)
	{
		u32 state_key1 = (GPIOE->IDR & 0x00000008) >> 3; //Use a state variable to eliminate the bouncing problem
		u32 state_buzzer = GPIOA->IDR & 0x00000001; //Use a state variable to eliminate the bouncing problem
		
		//Check whether Key2 is pressed(IDR at bit2 is 1), if yes, reset PB5 to turn off the lit, if no, set PB5 to turn on the lit
		if ((GPIOE->IDR & (1<<2)) != 0x00000004) { 
			GPIOB->BRR = 1<<5; //Set BR5 as 1, reset the corresponding ODR5 bit
		} else {
			GPIOB->BSRR = 1<<5; //Set BS5 as 1, set the corrsponding ODR5 bit
		}
		
		//Check whether the state of key1 for stablizing, if yes, check whether key1 is pressed, yes then reset led1, no then set led1; 
		if (state_key1 == 0) { //check the initial state of key1, originally on
			if ((GPIOE->ODR & 0x00000020) >> 5 != 0) { //check the set or reset state
				GPIOE->BRR = 1<<5; // reset led1, turn off it
			} else {
				GPIOE->BSRR = 1<<5; //set led1, turn on it
			}
			Delay(100000);
			//Check when bit3 of IDR is 0, state is 0, set the state to 1 so that in next while loop, the if content will not matter, remaining the led's state
			while (state_key1 == 0) {
				state_key1 = (GPIOE->IDR & 0X00000008) >> 3; //prevent led1 from change after release key1
				Delay(100000);
			}
		}
		
		//Check the state of keyup for stablizing, if yes, check whether keyup is pressed, yes then reset buzzer, no then set buzzer;
		if (state_buzzer == 1) { //check the initial state of buzzer, originally off
			if ((GPIOB->ODR & 0x00000100) >> 8 == 1) { //check the set or reset state
				GPIOB->BRR = 1<<8; // reset buzzer, turn off it
			} else {
				GPIOB->BSRR = 1<<8; //set buzzer, turn on it
			}
			Delay(10000);
			//Check when bit0 of IDR is 1, state is 1, set the state to 0 so that in next while loop, the if content will not matter, remaining the buzzer's state
			while (state_buzzer == 1) {
				state_buzzer = (GPIOA->IDR & 0X00000001); //prevent buzzer from change after release keyup
				Delay(10000);
			}
		}
	}
}
