#include "stm32f10x.h"

void Delay(u32 count) //Delay subroutines generate some time delay by looping
{
	u32 i;
	for (i=0;i<count;i++);
}

int main(void)
{
	GPIO_InitTypeDef GPIO_InitStructure; //Define a structure to configure the GPIO
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE); //Enable GPIOB
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_5; //Pin5
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_Out_PP; //Output Push-Pull mode
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz; //50MHz maximal speed
	GPIO_Init(GPIOB, &GPIO_InitStructure); //Set Pin5 of GPIOB wiwth the parameters above
	GPIO_SetBits(GPIOB, GPIO_Pin_5); //Set Pin5 of GPIOB: to high
	while(1)
	{
		GPIO_ResetBits(GPIOB, GPIO_Pin_5);
		Delay(10245901);
		GPIO_SetBits(GPIOB, GPIO_Pin_5);
		Delay(10245901);
	}
}
