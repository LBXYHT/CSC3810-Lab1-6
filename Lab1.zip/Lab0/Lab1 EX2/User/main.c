#include "stm32f10x.h"

void Delay(u32 count) //Delay subroutines generate some time delay by looping
{
	u32 i;
	for (i=0;i<count;i++);
}

int main(void)
{
	GPIO_InitTypeDef GPIO_InitStructure; //Define a structure to configure the GPIO
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOE, ENABLE); //Enable GPIOE
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_2; //Pin2
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_IPU; //Output Internal Pull-up mode
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz; //50MHz maximal speed
	GPIO_Init(GPIOE, &GPIO_InitStructure); //Set Pin2 of GPIOE wiwth the parameters above
	//GPIO_SetBits(GPIOE, GPIO_Pin_2); //Set Pin2 of GPIOE: to high
	
	GPIO_InitTypeDef GPIO_InitStructure1; //Define a structure to configure the GPIO
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE); //Enable GPIOB
	GPIO_InitStructure1.GPIO_Pin=GPIO_Pin_5; //Pin5
	GPIO_InitStructure1.GPIO_Mode=GPIO_Mode_Out_PP; //Output Push-Pull mode
	GPIO_InitStructure1.GPIO_Speed=GPIO_Speed_50MHz; //50MHz maximal speed
	GPIO_Init(GPIOB, &GPIO_InitStructure1); //Set Pin5 of GPIOB wiwth the parameters above
	GPIO_SetBits(GPIOB, GPIO_Pin_5); //Set Pin5 of GPIOB: to high

	while(1)
	{
		u8 returned_value = GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_2);
		if (returned_value==0) {
			GPIO_ResetBits(GPIOB, GPIO_Pin_5);
		} else {
			GPIO_SetBits(GPIOB, GPIO_Pin_5);
		}
	}
}
