#include "stm32f10x.h"
#include "EIE3810_TFTLCD.c"

void Delay(u32);

int main(void)
{
	//int i, j;
	EIE3810_TFTLCD_Init();
	EIE3810_TFTLCD_FillRectangle(0, 480, 0, 800, WHITE);
	Delay(1000000);	
	EIE3810_TFTLCD_FillRectangle(100, 100, 100, 100, YELLOW);
}

void Delay(u32 count) //Use looping for delay
{
	u32 i;
	for (i=0;i<count;i++);
}

