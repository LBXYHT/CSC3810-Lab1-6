#include "stm32f10x.h"
#include "EIE3810_TFTLCD.c"

void Delay(u32);

int main(void)
{
	int i, j;
	EIE3810_TFTLCD_Init();
	EIE3810_TFTLCD_FillRectangle(0, 480, 0, 800, WHITE);
	Delay(1000000);	
	for (j=0;j<5;j++)
	{
		if (j == 0)
		{
			for (i=0;i<20;i++)
			{
			EIE3810_TFTLCD_DrawDot(10 + i, 10, BLACK);
			}
		} 
		else if (j == 2)
		{
			for (i=0;i<20;i++)
			{
			EIE3810_TFTLCD_DrawDot(10 + i, 30, GREEN);
			}
		}
		else if (j == 3)
		{
			for (i=0;i<20;i++)
			{
			EIE3810_TFTLCD_DrawDot(10 + i, 40, RED);
			}
		}
		else if (j == 4)
		{
			for (i=0;i<20;i++)
			{
			EIE3810_TFTLCD_DrawDot(10 + i, 50, BLUE);
			}
		}
	}	

}

void Delay(u32 count) //Use looping for delay
{
	u32 i;
	for (i=0;i<count;i++);
}

