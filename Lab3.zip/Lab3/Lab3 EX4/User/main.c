#include "stm32f10x.h"
#include "EIE3810_TFTLCD.c"
#include "Font.H"

void Delay(u32);
void EIE3810_TFTLCD_ShowChar(u16 x, u16 y, u8 ASCII, u16 color, u16 bgcolor);

void exp_1();
void exp_2();
void exp_3();
void exp_4();



int main(void)
{
	//int i, j;
	EIE3810_TFTLCD_Init();
	EIE3810_TFTLCD_FillRectangle(0, 480, 0, 800, WHITE);
	Delay(1000000);	
	
	exp_1();
	exp_2();
	exp_4();
	exp_3();
}

void EIE3810_TFTLCD_ShowChar(u16 x, u16 y, u8 ASCII, u16 color, u16 bgcolor)
{
	if (ASCII >= 32 && ASCII <= 126)
	{
		EIE3810_TFTLCD_FillRectangle(x, 8, y, 16, bgcolor);
		for (int i=0;i<=15;i+=2)
		{
			for (int j=0;j<=15;j++)
			{
				if (j<8) 
				{
					int upper_bit = asc2_1608[ASCII-32][i] & 1<<j;
					if (upper_bit != 0)
					{
						EIE3810_TFTLCD_DrawDot(x + i/2, y - j+8, color);
					}
				}
				else 
				{
					int lower_bit = asc2_1608[ASCII-32][i+1] & 1<<(j-8);
					if (lower_bit != 0)
					{
						EIE3810_TFTLCD_DrawDot(x + i/2, y - j+23, color);
					}
				}
			}
		}
	}
}

void exp_1(void)
{
	int i, j;
	for (j=0;j<5;j++)
	{
		if (j == 0)
		{
			for (i=0;i<20;i++)
			{
			EIE3810_TFTLCD_DrawDot(10 + i, 10, BLACK);
			}
		} 
		else if (j == 2)
		{
			for (i=0;i<20;i++)
			{
			EIE3810_TFTLCD_DrawDot(10 + i, 30, GREEN);
			}
		}
		else if (j == 3)
		{
			for (i=0;i<20;i++)
			{
			EIE3810_TFTLCD_DrawDot(10 + i, 40, RED);
			}
		}
		else if (j == 4)
		{
			for (i=0;i<20;i++)
			{
			EIE3810_TFTLCD_DrawDot(10 + i, 50, BLUE);
			}
		}
	}	
}

void exp_2(void)
{
	EIE3810_TFTLCD_FillRectangle(100, 100, 100, 100, YELLOW);
}


void exp_3(void)
{
	while (1)
	{
		for (int i=9;i>=0;i--)
		{
			EIE3810_TFTLCD_SevenSegment(202, 470, i, BLUE);
			Delay(10245901);
			EIE3810_TFTLCD_FillRectangle(202, 75, 330, 140, WHITE);
		}
	}
}


void exp_4(void)
{
	EIE3810_TFTLCD_ShowChar(320, 720, '1', YELLOW, BLUE);
	EIE3810_TFTLCD_ShowChar(328, 720, '2', YELLOW, BLUE);
	EIE3810_TFTLCD_ShowChar(336, 720, '0', YELLOW, BLUE);
	EIE3810_TFTLCD_ShowChar(344, 720, '0', YELLOW, BLUE);
	EIE3810_TFTLCD_ShowChar(352, 720, '1', YELLOW, BLUE);
	EIE3810_TFTLCD_ShowChar(360, 720, '0', YELLOW, BLUE);
	EIE3810_TFTLCD_ShowChar(368, 720, '0', YELLOW, BLUE);
	EIE3810_TFTLCD_ShowChar(376, 720, '5', YELLOW, BLUE);
	EIE3810_TFTLCD_ShowChar(384, 720, '8', YELLOW, BLUE);
}

void Delay(u32 count) //Use looping for delay
{
	u32 i;
	for (i=0;i<count;i++);
}

