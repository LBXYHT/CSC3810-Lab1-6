#include "stm32f10x.h"
void EIE3810_LED_Init();
void EIE3810_NVIC_SetPriorityGroup(u8 prigroup);
void EIE3810_Key2_EXTIInit();
void EXTI2_IRQHandler(void);
void EIE3810_KeyUp_EXTIInit();
void EXTI0_IRQHandler(void);

#define DS0_OFF GPIOB->BSRR = 1<<5
#define DS0_ON GPIOB->BRR = 1<<5
#define DS1_OFF GPIOE->BSRR = 1<<5
#define DS1_ON GPIOE->BRR = 1<<5


void Delay(u32 count) //Delay subroutines generate some time delay by looping
{
	u32 i;
	for (i=0;i<count;i++);
}

int main(void)
{
	EIE3810_LED_Init();
	EIE3810_NVIC_SetPriorityGroup(5); //Set PRIGROUP
	EIE3810_Key2_EXTIInit(); //Initialize Key2 as an interrupt input
	EIE3810_KeyUp_EXTIInit(); //Initailize KeyUp as an interrupt input
	DS0_OFF;
	DS1_OFF;
	int count;
	while(1)
	{
		count++;//Just count.
	}
}


void EIE3810_Key2_EXTIInit(void)
{
	RCC->APB2ENR |= 1<<6; //Enable IOPE for the use of PE2
	GPIOE->CRL &=0xFFFFF0FF; //Clean the state of CNF2 and MODE2 in PE
	GPIOE->CRL |=0x00000800; //Set the state of CNF2 as 10(input with pull-up  / pull-down) amd MODE2 as 00(input mode)
	GPIOE->ODR |= 1<<2; //Set bit2 of ODR as 1 to let PE2 port output data
	RCC->APB2ENR |=0x01; //Enable AFIO
	AFIO->EXTICR[0] &=0xFFFFF0FF; //Clean the state of EXTI2
	AFIO->EXTICR[0] |=0x00000400; //Set the state of EXTI2 as 0100 to select PE2 pin
	EXTI->IMR |= 1<<2; //Set 1 to MR2 of IMR, for interrupt request from line 2 not masked
	//EXTI->FTSR |= 1<<2; //Set falling trigger selection register for pin 2
	EXTI->RTSR |= 1<<2; //Set rising trigger selection register for pin 2
	NVIC->IP[8] = 0X65; //Set the priority register of EXTI2
	NVIC->ISER[0] |= (1<<8); //Enbale interrupt position #8
}

void EIE3810_NVIC_SetPriorityGroup(u8 prigroup)
{
	u32 temp1, temp2;
	temp2= prigroup&0x00000007;
	temp2 <<=8; //move temp2 offset left 8 bits, last 8 bits of temp1 is 00 and [10:8] in SCB->AIRCR is the priority group so the movement corrects the position
	temp1 = SCB->AIRCR; //Read AIRCR in SCB configuration struct for application interrupt / Reset control register
	temp1 &=0x0000F8FF; //Clean bits 8, 9, 11, 16-31 of temp1
	temp1 |=0x05FA0000; //Set bits [27, 16] of temp1 as 010111111010 for orequal calculation with temp2
	temp1 |= temp2;
	SCB->AIRCR = temp1;
}

void EXTI2_IRQHandler(void)
{
	u8 i;
	
	for (i=0;i<10;i++)
	{
		DS0_ON;
		Delay(3000000);
		DS0_OFF;
		Delay(3000000);
	}
	EXTI->PR = 1<<2; //set PR2 as 1, corresponding pending bit slected trigger request occurred
}


void EIE3810_LED_Init(void)
{
	RCC->APB2ENR|=1<<6; //Set RCC->APB2ENR as 1 with offset 6, equaling to set bit IOPEEN as 1
	RCC->APB2ENR|=1<<3; //Set RCC->APB2ENR as 1 with offset 3(or logic), equaling to set bit IOPBEN as 1
	
	//Initialize DS1
	GPIOE->CRL &= 0xFF0FFFFF; //Set CRL to 0x44044444, set all CNFy as 01(general purpose output Open-drain) except CNF5, CNF5 remains push-pull
	GPIOE->CRL |= 0x00300000; //Set CRL to 0x44344444, set MODE as 11(max speed 50MHz)
	
	//Initialize DS0
	GPIOB->CRL &= 0xFF0FFFFF; //Set CRL to 0x44044444, set all CNFy as 01(general purpose output Open-drain) except CNF5, CNF5 remains push-pull
	GPIOB->CRL |= 0x00300000; //Set CRL to 0x44344444, set MODE as 11(max speed 50MHz)
}

void EIE3810_KeyUp_EXTIInit(void)
{
	RCC->APB2ENR |= 1<<2; //Enable IOPA for the use of PA0
	GPIOA->CRL &=0xFFFFFFF0; //Clean the state of CNF0 and MODE0 in PA
	GPIOA->CRL |=0x00000008; //Set the state of CNF0 as 10(input with pull-up  / pull-down) amd MODE0 as 00(input mode)
	GPIOA->ODR &= 0; //Set bit0 of ODR as 1 to let PA0 port output data
	RCC->APB2ENR |=0x01; //Enable AFIO
	AFIO->EXTICR[0] &=0xFFFFFFF0; //Clean the state of EXTI0
	AFIO->EXTICR[0] |=0x00000000; //Set the state of EXTI0 as 0000 to select PA0 pin
	EXTI->IMR |= 1; //Set 1 to MR0 of IMR, for interrupt request from line 0 not masked
	EXTI->FTSR |= 1<<0; //Set falling trigger selection register for pin 0
	//EXTI->RTSR |= 1<<0; //Set rising trigger selection register for pin 0
	NVIC->IP[6] = 0X35; //Set the priority register of EXTI0
	NVIC->ISER[0] |= (1<<6); //Enbale interrupt position #6
}

void EXTI0_IRQHandler(void)
{
	u8 i;
	
	for (i=0;i<10;i++)
	{
		DS1_ON;
		Delay(3000000);
		DS1_OFF;
		Delay(3000000);
	}
	EXTI->PR = 1<<0; //set PR0 as 1, corresponding pending bit slected trigger request occurred
}
