#include "stm32f10x.h"
#include "EIE3810_TFTLCD.h"
#include "EIE3810_Clock.h"
#include "EIE3810_USART.h"
#include "Font.H"

void EIE3810_NVIC_SetPriorityGroup(u8 prigroup);
void EIE3810_LED_Init();
void EIE3810_USART1_EXTIInit();
void display_sixteen_bits(u16 x, u16 y, u16 bgcolor, u32 reg_num);
void display_num(u16 x, u16 y, u16 bgcolor);

void Delay(u32);


#define DS0_OFF GPIOB->BSRR = 1<<5
#define DS0_ON GPIOB->BRR = 1<<5
#define DS1_OFF GPIOE->BSRR = 1<<5
#define DS1_ON GPIOE->BRR = 1<<5


int main(void)
{
	//int i, j;
	EIE3810_clock_tree_init();
	EIE3810_LED_Init();
	EIE3810_TFTLCD_Init();
	Delay(500000);
	//EIE3810_TFTLCD_Clear(WHITE);
	EIE3810_TFTLCD_FillRectangle(0, 480, 0, 800, WHITE);
	EIE3810_NVIC_SetPriorityGroup(5); //Set PRIGROUP
	EIE3810_USART1_init(72, 9600);
	EIE3810_USART1_EXTIInit();
	USART_print(1, "1234567890");
	
	while(1)
	{
		USART_print(1, "EIE3810_Lab4");
		while (!((USART1->SR >> 7) & 0x1));
		Delay(10000000);
	}
}

void EIE3810_TFTLCD_ShowChar(u16 x, u16 y, u8 ASCII, u16 color, u16 bgcolor)
{
	if (ASCII >= 32 && ASCII <= 126)
	{
		EIE3810_TFTLCD_FillRectangle(x, 8, y, 16, bgcolor);
		for (int i=0;i<=15;i+=2)
		{
			for (int j=0;j<=15;j++)
			{
				if (j<8) 
				{
					int upper_bit = asc2_1608[ASCII-32][i] & 1<<j;
					if (upper_bit != 0)
					{
						EIE3810_TFTLCD_DrawDot(x + i/2, y - j+8, color);
					}
				}
				else 
				{
					int lower_bit = asc2_1608[ASCII-32][i+1] & 1<<(j-8);
					if (lower_bit != 0)
					{
						EIE3810_TFTLCD_DrawDot(x + i/2, y - j+23, color);
					}
				}
			}
		}
	}
}

void Delay(u32 count) //Use looping for delay
{
	u32 i;
	for (i=0;i<count;i++);
}


void EIE3810_NVIC_SetPriorityGroup(u8 prigroup)
{
	u32 temp1, temp2;
	temp2= prigroup&0x00000007;
	temp2 <<=8; //move temp2 offset left 8 bits, last 8 bits of temp1 is 00 and [10:8] in SCB->AIRCR is the priority group so the movement corrects the position
	temp1 = SCB->AIRCR; //Read AIRCR in SCB configuration struct for application interrupt / Reset control register
	temp1 &=0x0000F8FF; //Clean bits 8, 9, 11, 16-31 of temp1
	temp1 |=0x05FA0000; //Set bits [27, 16] of temp1 as 010111111010 for orequal calculation with temp2
	temp1 |= temp2;
	SCB->AIRCR = temp1;
}

void EIE3810_LED_Init(void)
{
	RCC->APB2ENR|=1<<6; //Set RCC->APB2ENR as 1 with offset 6, equaling to set bit IOPEEN as 1
	RCC->APB2ENR|=1<<3; //Set RCC->APB2ENR as 1 with offset 3(or logic), equaling to set bit IOPBEN as 1
	
	//Initialize DS1
	GPIOE->CRL &= 0xFF0FFFFF; //Set CRL to 0x44044444, set all CNFy as 01(general purpose output Open-drain) except CNF5, CNF5 remains push-pull
	GPIOE->CRL |= 0x00300000; //Set CRL to 0x44344444, set MODE as 11(max speed 50MHz)
	
	//Initialize DS0
	GPIOB->CRL &= 0xFF0FFFFF; //Set CRL to 0x44044444, set all CNFy as 01(general purpose output Open-drain) except CNF5, CNF5 remains push-pull
	GPIOB->CRL |= 0x00300000; //Set CRL to 0x44344444, set MODE as 11(max speed 50MHz)
	
	DS0_OFF;
	DS1_OFF;
	
}

void EIE3810_USART1_EXTIInit(void)
{
	NVIC->IP[37] = 0x65; //Set 01100101 to priority register of interrupt position #37
	NVIC->ISER[1] |= 1<<5; //Enable interrupt position #37
}

void USART1_IRQHandler(void)
{
	u32 buffer;
	if (USART1->SR & (1<<5)) //Set bit5 to 1 to say received data is ready to be read
	{
		buffer=USART1->DR; //Use buffer to read data value from DR
		if(buffer == 'Q')
			{DS0_ON; //Turn on LED0
				}
		else if(buffer=='H')
			{DS0_OFF; //Turn off LED0
				}
		else if(buffer=='R')
			{
				display_num(0, 16, RED);
				display_sixteen_bits(0, 0, RED, USART1->CR1);
				Delay(10000);
				display_num(0, 56, BLUE);
				display_sixteen_bits(0, 40, BLUE, USART1->CR1);
				EIE3810_TFTLCD_ShowChar(120, 200, 'R', YELLOW, GREEN);
				}
	}
}

void display_sixteen_bits(u16 x, u16 y, u16 bgcolor, u32 reg_num)
{
	u32 current = reg_num;
	int i;
	for (i=0;i<16;i++)
	{
		if (i%2 == 0)
		{
			EIE3810_TFTLCD_ShowChar(x+(15-i)*24, y, '0'+(current%2), WHITE, bgcolor);
		}
		else 
		{
			EIE3810_TFTLCD_ShowChar(x+(15-i)*24, y, '0'+(current%2), bgcolor, WHITE);
		}
		current /= 2;
	}
}

void display_num(u16 x, u16 y, u16 bgcolor)
{
	int i;
	for(i=0;i<10;i++)
	{
		if (i%2 == 1)
		{
			EIE3810_TFTLCD_ShowChar(x+(15-i)*24, y, '0'+i, bgcolor, WHITE);
		}
		else 
		{
			EIE3810_TFTLCD_ShowChar(x+(15-i)*24, y, '0'+i, WHITE, bgcolor);
		}
	}
	
	for(i=0;i<6;i++)
	{
		if (i%2 == 1)
		{
			EIE3810_TFTLCD_ShowChar(x+(5-i)*24, y, '1', bgcolor, WHITE);
			EIE3810_TFTLCD_ShowChar(x+(5-i)*24 + 8, y, '0'+i, bgcolor, WHITE);
		}
		else{
			EIE3810_TFTLCD_ShowChar(x+(5-i)*24, y, '1', WHITE, bgcolor);
			EIE3810_TFTLCD_ShowChar(x+(5-i)*24 + 8, y, '0'+i, WHITE, bgcolor);
		}
	}
}
